(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("form1");
            this.set_titletext("Form_Work");
            if (Form == this.constructor)
            {
                this._setFormPosition(1280,720);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("Dataset00", this);
            obj._setContents("");
            this.addChild(obj.name, obj);


            obj = new Dataset("Dataset01", this);
            obj._setContents("");
            this.addChild(obj.name, obj);


            obj = new Dataset("Dataset02", this);
            obj._setContents("<ColumnInfo><Column id=\"Column0\" type=\"STRING\" size=\"256\"/><Column id=\"Column1\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);


            obj = new TCPClientSocket("TCPClientSocket00", this);
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new Button("Button00","45","140","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_text("open");
            this.addChild(obj.name, obj);

            obj = new Static("Static00","5","81","60","30",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_text("server ip");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit00","64","77","91","38",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_value("172.10.12.45");
            obj.set_text("172.10.12.45");
            this.addChild(obj.name, obj);

            obj = new Static("Static00_00","161","81","39","30",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_text("port");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit00_00","197","78","53","37",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_value("6000");
            obj.set_inputtype("number");
            obj.set_text("6000");
            this.addChild(obj.name, obj);

            obj = new Button("Button01","150","140","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_text("close");
            this.addChild(obj.name, obj);

            obj = new Button("Button03","340","470","189","60",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_text("textarea clear");
            this.addChild(obj.name, obj);

            obj = new Button("Button02","254","140","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_text("readline");
            this.addChild(obj.name, obj);

            obj = new Static("Static01_00","34","8","313","53",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_text("5. readLine Method 테스트 ");
            this.addChild(obj.name, obj);

            obj = new Static("Static00_00_00","470","81","60","30",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_text("strCharSet");
            this.addChild(obj.name, obj);

            obj = new Static("Static00_00_00_00","265","81","60","30",null,null,null,null,null,null,this);
            obj.set_taborder("10");
            obj.set_text("nSize");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_nSize","300","78","43","37",null,null,null,null,null,null,this);
            obj.set_taborder("11");
            obj.set_value("10");
            obj.set_inputtype("number");
            obj.set_text("10");
            this.addChild(obj.name, obj);

            obj = new Grid("Grid00","630","39","646","681",null,null,null,null,null,null,this);
            obj.set_taborder("12");
            obj.set_binddataset("Dataset02");
            obj.set_autofittype("col");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"34\"/><Column size=\"598\"/></Columns><Rows><Row size=\"24\" band=\"head\"/><Row size=\"50\"/></Rows><Band id=\"head\"><Cell text=\"NO\"/><Cell col=\"1\" text=\"Column1\"/></Band><Band id=\"body\"><Cell text=\"bind:Column0\"/><Cell col=\"1\" text=\"bind:Column1\" displaytype=\"text\" edittype=\"text\" textAlign=\"left\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);

            obj = new Static("Static00_00_00_01","354","81","60","30",null,null,null,null,null,null,this);
            obj.set_taborder("13");
            obj.set_text("nTimeOut");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_nTimeOut","414","78","43","37",null,null,null,null,null,null,this);
            obj.set_taborder("14");
            obj.set_value("1");
            obj.set_inputtype("number");
            obj.set_text("1");
            this.addChild(obj.name, obj);

            obj = new Combo("cbo_strCharSet","535","80","75","37",null,null,null,null,null,null,this);
            obj.set_taborder("15");
            obj.set_codecolumn("codecolumn");
            obj.set_datacolumn("datacolumn");
            obj.set_buttonsize("15");
            var cbo_strCharSet_innerdataset = new nexacro.NormalDataset("cbo_strCharSet_innerdataset", obj);
            cbo_strCharSet_innerdataset._setContents("<ColumnInfo><Column id=\"codecolumn\" size=\"256\"/><Column id=\"datacolumn\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"codecolumn\">1</Col><Col id=\"datacolumn\">utf-8</Col></Row><Row><Col id=\"codecolumn\">2</Col><Col id=\"datacolumn\">euc-kr</Col></Row></Rows>");
            obj.set_innerdataset(cbo_strCharSet_innerdataset);
            obj.set_text("utf-8");
            obj.set_value("1");
            obj.set_index("0");
            this.addChild(obj.name, obj);
            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","Desktop_screen",1280,720,this,function(p){});
            this.addLayout(obj.name, obj);
            
            // BindItem Information

            
            // TriggerItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("TCPClientSocket_TestCase5.xfdl", function() {

        this.Button00_onclick = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.open start");
        	let userSocket = this.TCPClientSocket00.open(this.Edit00.value, this.Edit00_00.value);
        	uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	let rnt =" this.TCPClientSocket00.open return value="+userSocket;
        	this.Dataset02.setColumn(uRow,1,rnt);
        };

        this.TCPClientSocket00_onerror = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	let uReturn = " e.eventid :"+e.eventid + ", e.statuscode : "+e.statuscode+", e.errormsg : "+e.errormsg;
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,uReturn);

        };

        this.TCPClientSocket00_onsuccess = function(obj,e)
        {

        	let uRow = this.Dataset02.addRow();
        	let uReturn = " e.eventid :"+e.eventid + ", e.reason : "+e.reason+", e.reasonmsg : "+e.reasonmsg+", e.bytessent : "+e.bytessent+", e.bytesremain : "+e.bytesremain;
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,uReturn);
        };

        this.TCPClientSocket00_ondataarrived = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	let uReturn =" e.eventid :"+e.eventid + ", e.bytesread : "+e.bytesread;
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,uReturn);
        	//this.edt_bytesread.value = e.bytesread;
        };



        this.Button01_onclick = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.close start");
        	let userSocket = this.TCPClientSocket00.close();
        	uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	let rnt =" this.TCPClientSocket00.close return value="+userSocket;
        	this.Dataset02.setColumn(uRow,1,rnt);
        };

        this.Button03_onclick = function(obj,e)
        {
        	this.Dataset02.clearData();

        };

        this.Button02_onclick = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.write start");
        	trace(" this.TCPClientSocket00.write start");
        	trace("nSize : "+this.edt_nSize.value+", nTimeOut : "+this.edt_nTimeOut.value+", strCharSet : "+this.cbo_strCharSet.text);
        	let bSucc = this.TCPClientSocket00.readLine(this.edt_nSize.value,this.edt_nTimeOut.value,this.cbo_strCharSet.text);
        	uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,"bSucc[0] : "+bSucc[0]);
        	uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,"bSucc[1] : "+bSucc[1]);
        	uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.write end");
        };

        this.Button04_onclick = function(obj,e)
        {
        	trace(this.Combo00.text);
        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.Button00.addEventHandler("onclick",this.Button00_onclick,this);
            this.Button01.addEventHandler("onclick",this.Button01_onclick,this);
            this.Button03.addEventHandler("onclick",this.Button03_onclick,this);
            this.Button02.addEventHandler("onclick",this.Button02_onclick,this);
            this.TCPClientSocket00.addEventHandler("onerror",this.TCPClientSocket00_onerror,this);
            this.TCPClientSocket00.addEventHandler("onsuccess",this.TCPClientSocket00_onsuccess,this);
            this.TCPClientSocket00.addEventHandler("ondataarrived",this.TCPClientSocket00_ondataarrived,this);
        };
        this.loadIncludeScript("TCPClientSocket_TestCase5.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
