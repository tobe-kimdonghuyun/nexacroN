(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_Work");
            this.set_titletext("New Form");
            if (Form == this.constructor)
            {
                this._setFormPosition(1280,720);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize

            
            // UI Components Initialize
            obj = new Div("Div00","0","100",null,null,"0","0",null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_text("Div00");
            this.addChild(obj.name, obj);

            obj = new Combo("Combo00","44","11","488","60",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_codecolumn("codecolumn");
            obj.set_datacolumn("datacolumn");
            var Combo00_innerdataset = new nexacro.NormalDataset("Combo00_innerdataset", obj);
            Combo00_innerdataset._setContents("<ColumnInfo><Column id=\"codecolumn\" size=\"256\"/><Column id=\"datacolumn\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"codecolumn\">1</Col><Col id=\"datacolumn\">FrameBase::TCPClientSocket_TestCase1.xfdl</Col></Row><Row><Col id=\"codecolumn\">2</Col><Col id=\"datacolumn\">FrameBase::TCPClientSocket_TestCase2.xfdl</Col></Row><Row><Col id=\"codecolumn\">3</Col><Col id=\"datacolumn\">FrameBase::TCPClientSocket_TestCase3.xfdl</Col></Row><Row><Col id=\"datacolumn\">FrameBase::TCPClientSocket_TestCase4.xfdl</Col><Col id=\"codecolumn\">4</Col></Row><Row><Col id=\"datacolumn\">FrameBase::TCPClientSocket_TestCase5.xfdl</Col><Col id=\"codecolumn\">5</Col></Row><Row><Col id=\"datacolumn\">FrameBase::TCPClientSocket_TestCase6.xfdl</Col><Col id=\"codecolumn\">6</Col></Row><Row><Col id=\"datacolumn\">FrameBase::TCPClientSocket_TestCase7.xfdl</Col><Col id=\"codecolumn\">7</Col></Row><Row><Col id=\"datacolumn\">FrameBase::TCPClientSocket_TestCase8.xfdl</Col><Col id=\"codecolumn\">8</Col></Row><Row><Col id=\"datacolumn\">FrameBase::TCPClientSocket_TestCase9.xfdl</Col><Col id=\"codecolumn\">9</Col></Row><Row><Col id=\"datacolumn\">FrameBase::TCPClientSocket_TestCase10.xfdl</Col><Col id=\"codecolumn\">10</Col></Row></Rows>");
            obj.set_innerdataset(Combo00_innerdataset);
            obj.set_text("Combo00");
            this.addChild(obj.name, obj);
            // Layout Functions
            //-- Default Layout : this.Div00
            obj = new Layout("default","",0,0,this.Div00.form,function(p){});
            this.Div00.form.addLayout(obj.name, obj);

            //-- Default Layout : this
            obj = new Layout("default","",1280,720,this,function(p){});
            this.addLayout(obj.name, obj);
            
            // BindItem Information

            
            // TriggerItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("Form_Work.xfdl", function() {

        this.Combo00_onitemchanged = function(obj,e)
        {
        	this.Div00.set_url(e.posttext);
        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.Combo00.addEventHandler("onitemchanged",this.Combo00_onitemchanged,this);
        };
        this.loadIncludeScript("Form_Work.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
