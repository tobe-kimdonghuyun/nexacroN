(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_Work");
            this.set_titletext("Form_Work");
            if (Form == this.constructor)
            {
                this._setFormPosition(1280,720);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new TCPClientSocket("TCPClientSocket00", this);
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new Button("Button00","90","206","213","71",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_text("open");
            this.addChild(obj.name, obj);

            obj = new Button("Button01","334","206","196","78",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_text("close");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit00","90","350","280","56",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static00","86","302","304","37",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_text("아래 에디트에 전송할 텍스트 입력");
            obj.set_font("bold 14px/normal \"Malgun Gothic\"");
            this.addChild(obj.name, obj);

            obj = new Button("Button02","398","348","196","62",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_text("전송");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new TextArea("TextArea00","89","500","487","204",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_wordWrap("char");
            obj.set_readonly("true");
            obj.set_font("bold 16px/normal \"Malgun Gothic\"");
            this.addChild(obj.name, obj);

            obj = new Static("Static01","89","440","418","47",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_text("아래 TextArea에는 서로 주고받은 텍스트 내용이 출력됩니다.");
            obj.set_font("bold 14px/normal \"Malgun Gothic\"");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit01","90","130","186","51",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_value("172.10.12.45");
            obj.set_text("172.10.12.45");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit02","400","130","190","54",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_value("9090");
            obj.set_text("9090");
            this.addChild(obj.name, obj);

            obj = new Static("Static02","28","130","51","51",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_text("IP :");
            obj.set_font("bold 20px/normal \"Malgun Gothic\"");
            this.addChild(obj.name, obj);

            obj = new Static("Static02_00","320","132","70","51",null,null,null,null,null,null,this);
            obj.set_taborder("10");
            obj.set_text("PORT :");
            obj.set_font("bold 20px/normal \"Malgun Gothic\"");
            this.addChild(obj.name, obj);

            obj = new Button("Button03","560","199","226","92",null,null,null,null,null,null,this);
            obj.set_taborder("11");
            obj.set_text("File wrirte");
            this.addChild(obj.name, obj);

            obj = new Button("Button04","832","192","269","102",null,null,null,null,null,null,this);
            obj.set_taborder("12");
            obj.set_text("Button04");
            this.addChild(obj.name, obj);

            obj = new Static("Static01_00","34","8","313","53",null,null,null,null,null,null,this);
            obj.set_taborder("13");
            obj.set_text("11. write Method 테스트 -File단위");
            this.addChild(obj.name, obj);
            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","Desktop_screen",1280,720,this,
            	//-- Layout function
            	function(p)
            	{
                var rootobj = p;
                p = rootobj;
                p.set_titletext("Form_Work");

                p.Button00.set_taborder("2");
                p.Button00.set_text("open");
                p.Button00.move("90","206","213","71",null,null);

                p.Button01.set_taborder("3");
                p.Button01.set_text("close");
                p.Button01.move("334","206","196","78",null,null);

                p.Edit00.set_taborder("4");
                p.Edit00.set_enable("false");
                p.Edit00.move("90","350","280","56",null,null);

                p.Static00.set_taborder("5");
                p.Static00.set_text("아래 에디트에 전송할 텍스트 입력");
                p.Static00.set_font("bold 14px/normal \"Malgun Gothic\"");
                p.Static00.move("86","302","304","37",null,null);

                p.Button02.set_taborder("6");
                p.Button02.set_text("전송");
                p.Button02.set_enable("false");
                p.Button02.move("398","348","196","62",null,null);

                p.TextArea00.set_taborder("7");
                p.TextArea00.set_wordWrap("char");
                p.TextArea00.set_readonly("true");
                p.TextArea00.set_font("bold 16px/normal \"Malgun Gothic\"");
                p.TextArea00.move("89","500","487","204",null,null);

                p.Static01.set_taborder("8");
                p.Static01.set_text("아래 TextArea에는 서로 주고받은 텍스트 내용이 출력됩니다.");
                p.Static01.set_font("bold 14px/normal \"Malgun Gothic\"");
                p.Static01.move("89","440","418","47",null,null);

                p.Edit01.set_taborder("0");
                p.Edit01.set_value("172.10.12.45");
                p.Edit01.move("90","130","186","51",null,null);

                p.Edit02.set_taborder("1");
                p.Edit02.set_value("9090");
                p.Edit02.move("400","130","190","54",null,null);

                p.Static02.set_taborder("9");
                p.Static02.set_text("IP :");
                p.Static02.set_font("bold 20px/normal \"Malgun Gothic\"");
                p.Static02.move("28","130","51","51",null,null);

                p.Static02_00.set_taborder("10");
                p.Static02_00.set_text("PORT :");
                p.Static02_00.set_font("bold 20px/normal \"Malgun Gothic\"");
                p.Static02_00.move("320","132","70","51",null,null);

                p.Button03.set_taborder("11");
                p.Button03.set_text("File wrirte");
                p.Button03.move("560","199","226","92",null,null);

                p.Button04.set_taborder("12");
                p.Button04.set_text("Button04");
                p.Button04.move("832","192","269","102",null,null);

                p.Static01_00.set_taborder("13");
                p.Static01_00.set_text("11. write Method 테스트 -File단위");
                p.Static01_00.move("34","8","313","53",null,null);
            	}
            );
            this.addLayout(obj.name, obj);

            //-- Normal Layout : this
            obj = new Layout("Layout0","Desktop_screen",900,600,this,
            	//-- Layout function
            	function(p)
            	{
                var rootobj = p;
                p = rootobj;

            	}
            );
            obj.set_mobileorientation("Landscape");
            obj.set_type("default");
            this.addLayout(obj.name, obj);
            
            // BindItem Information

            
            // TriggerItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("TCPClientSocket_TestCase10.xfdl", function() {
        this.__read_size = 0;
        this.Button00_onclick = function(obj,e)
        {
        	trace("TCPClientSocket Open == " + this.TCPClientSocket00.open(this.Edit01.text, this.Edit02.text));
        };

        this.Button01_onclick = function(obj,e)
        {
        	trace("TCPClientSocket Close == " + this.TCPClientSocket00.close());
        };

        this.Button02_onclick = function(obj,e)
        {
        	trace("TCPClientSocket write == " + this.TCPClientSocket00.write(this.Edit00.text, "utf-8"));
        	if (this.TextArea00.getLength() == 0)
        	{
        		this.TextArea00.set_value("Client : " + this.Edit00.text);
        	}
        	else
        	{
        		this.TextArea00.set_value(this.TextArea00.text + "\n" + "Client : " + this.Edit00.text);
        	}
        };

        this.TCPClientSocket00_onsuccess = function(obj,e)
        {
        	if (e.reason == 1) // open
        	{
        		this.Edit00.set_enable(true);
        		this.Edit00.set_value("");
        		this.Button02.set_enable(true);
        	}
        	else if (e.reason == 2) // close
        	{
        		this.Edit00.set_enable(false);
        		this.Edit00.set_value("");
        		this.Button02.set_enable(false);
        	}

        	trace("\n" +
        		"e.bytesremain == " + e.bytesremain + "\n" +
        		"e.bytessent == " + e.bytessent + "\n" +
        		"e.eventid == " + e.eventid + "\n" +
        		"e.reason == " + e.reason + "\n" +
        		"e.reasonmsg == " + e.reasonmsg + "\n"
        	)
        };
        this.fullSize;
        this.TCPClientSocket00_ondataarrived = function(obj,e)
        {
        	this.__read_size =e.bytesread;
        	trace("this.TCPClientSocket00_ondataarrived: bytes => " + e.bytesread);
        	if (e.bytesread > 0)
        	{
        		var ret = this.TCPClientSocket00.read(e.bytesread, 30, "utf-8");
        		this.TextArea00.insertText(ret[1]);
        	}
        	this.fullSize = e.bytesread;
        };

        this.Button03_onclick = function(obj,e)
        {
        	//testFile
        	this.TCPClientSocket00.write("GET /transkey.js HTTP/1.1\r\nHost: 172.10.12.45:9090\r\n\r\n");
        };

        this.Button04_onclick = function(obj,e)
        {
        	var readSize = this.__read_size;
        	if (readSize <= 0)
        		readSize = 1024;

        	var ret = this.TCPClientSocket00.read(readSize, 30, "utf-8");
        	if (ret[0])
        	{
        		var str = ret[1];
        		var text = this.TextArea00.value;
        		if (!text)
        			text = str;
        		else
        			text += str;
        		this.TextArea00.set_value(text);

        		 trace("TCPClientSocket00<readLine>: str => " + str);
        	}
        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.Button00.addEventHandler("onclick",this.Button00_onclick,this);
            this.Button01.addEventHandler("onclick",this.Button01_onclick,this);
            this.Button02.addEventHandler("onclick",this.Button02_onclick,this);
            this.Button03.addEventHandler("onclick",this.Button03_onclick,this);
            this.Button04.addEventHandler("onclick",this.Button04_onclick,this);
            this.TCPClientSocket00.addEventHandler("onsuccess",this.TCPClientSocket00_onsuccess,this);
            this.TCPClientSocket00.addEventHandler("ondataarrived",this.TCPClientSocket00_ondataarrived,this);
        };
        this.loadIncludeScript("TCPClientSocket_TestCase10.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
