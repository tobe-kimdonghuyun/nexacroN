(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_Work");
            this.set_titletext("Form_Work");
            if (Form == this.constructor)
            {
                this._setFormPosition(1280,720);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("Dataset00", this);
            obj._setContents("");
            this.addChild(obj.name, obj);


            obj = new Dataset("Dataset01", this);
            obj._setContents("");
            this.addChild(obj.name, obj);


            obj = new Dataset("Dataset02", this);
            obj._setContents("<ColumnInfo><Column id=\"Column0\" type=\"STRING\" size=\"256\"/><Column id=\"Column1\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);


            obj = new TCPClientSocket("TCPClientSocket00", this);
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new Button("Button00","7","145","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_text("open");
            this.addChild(obj.name, obj);

            obj = new Static("Static00","30","80","60","30",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_text("server ip");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit00","108","73","152","53",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_value("172.10.12.45");
            obj.set_text("172.10.12.45");
            this.addChild(obj.name, obj);

            obj = new Static("Static00_00","282","81","60","30",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_text("server port");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit00_00","360","74","152","53",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_value("6000");
            obj.set_text("6000");
            this.addChild(obj.name, obj);

            obj = new Button("Button01","112","145","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_text("close");
            this.addChild(obj.name, obj);

            obj = new Button("Button03","340","470","189","60",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_text("textarea clear");
            this.addChild(obj.name, obj);

            obj = new Grid("Grid00","567","39","679","484",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_binddataset("Dataset02");
            obj.set_autofittype("col");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"34\"/><Column size=\"598\"/></Columns><Rows><Row size=\"24\" band=\"head\"/><Row size=\"50\"/></Rows><Band id=\"head\"><Cell text=\"NO\"/><Cell col=\"1\" text=\"Column1\"/></Band><Band id=\"body\"><Cell text=\"bind:Column0\"/><Cell col=\"1\" text=\"bind:Column1\" displaytype=\"text\" edittype=\"text\" textAlign=\"left\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);

            obj = new Button("Button02","218","145","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_text("isOpen");
            this.addChild(obj.name, obj);

            obj = new Button("Button04","323","145","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_text("port");
            this.addChild(obj.name, obj);

            obj = new Button("Button05","430","145","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("10");
            obj.set_text("name");
            this.addChild(obj.name, obj);

            obj = new Button("Button06","7","205","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("11");
            obj.set_text("address");
            this.addChild(obj.name, obj);

            obj = new Button("Button06_00","112","205","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("12");
            obj.set_text("errorcode");
            this.addChild(obj.name, obj);

            obj = new Button("Button06_00_00","218","205","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("13");
            obj.set_text("errormsg");
            this.addChild(obj.name, obj);

            obj = new Button("Button06_00_00_00","323","205","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("14");
            obj.set_text("errormsg");
            this.addChild(obj.name, obj);

            obj = new Static("Static01","34","8","313","53",null,null,null,null,null,null,this);
            obj.set_taborder("15");
            obj.set_text("1. Property테스트");
            this.addChild(obj.name, obj);
            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","Desktop_screen",1280,720,this,function(p){});
            this.addLayout(obj.name, obj);
            
            // BindItem Information

            
            // TriggerItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("TCPClientSocket_TestCase1.xfdl", function() {

        this.Button00_onclick = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        //	this.TextArea00.insertText(" this.TCPClientSocket00.close start \n");
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.open start");
        	let userSocket = this.TCPClientSocket00.open(this.Edit00.value, this.Edit00_00.value);
        	uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	let rnt =" this.TCPClientSocket00.open return value="+userSocket;
        	this.Dataset02.setColumn(uRow,1,rnt);
        	//this.TextArea00.insertText("  this.TCPClientSocket00.open return value="+userSocket);
        	//this.TCPClientSocket00.open("172.10.2.65", 58080);
        };

        this.TCPClientSocket00_onerror = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	let uReturn = " e.eventid :"+e.eventid + ", e.statuscode : "+e.statuscode+", e.errormsg : "+e.errormsg;
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,uReturn);
        	//this.TextArea00.insertText(" e.eventid :"+e.eventid + ", e.statuscode : "+e.statuscode+", e.errormsg : "+e.errormsg+"\n");

        };

        this.TCPClientSocket00_onsuccess = function(obj,e)
        {

        	let uRow = this.Dataset02.addRow();
        	let uReturn = " e.eventid :"+e.eventid + ", e.reason : "+e.reason+", e.reasonmsg : "+e.reasonmsg+", e.bytessent : "+e.bytessent+", e.bytesremain : "+e.bytesremain;
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,uReturn);
        	//this.TextArea00.insertText(" e.eventid :"+e.eventid + ", e.reason : "+e.reason+", e.reasonmsg : "+e.reasonmsg+", e.bytessent : "+e.bytessent+", e.bytesremain : "+e.bytesremain+"\n");
        };

        this.TCPClientSocket00_ondataarrived = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	let uReturn =" e.eventid :"+e.eventid + ", e.bytesread : "+e.bytesread;
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,uReturn);
        	//this.TextArea00.insertText(" e.eventid :"+e.eventid + ", e.bytesread : "+e.bytesread+"\n");
        };



        this.Button01_onclick = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.close start");
        	//this.TextArea00.insertText(" this.TCPClientSocket00.close start \n");
        	let userSocket = this.TCPClientSocket00.close();
        	uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	let rnt =" this.TCPClientSocket00.close return value="+userSocket;
        	this.Dataset02.setColumn(uRow,1,rnt);
        	//this.TextArea00.insertText(" this.TCPClientSocket00.close return value="+userSocket);

        };

        this.Button03_onclick = function(obj,e)
        {
        	this.Dataset02.clearData();

        };

        this.Button02_onclick = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.isopen  : "+this.TCPClientSocket00.isopen);
        };

        this.Button05_onclick = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.name  : "+this.TCPClientSocket00.name);
        };

        this.Button04_onclick = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.port  : "+this.TCPClientSocket00.port);
        };

        this.Button06_onclick = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.address  : "+this.TCPClientSocket00.address);
        };

        this.Button06_00_onclick = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.errorcode  : "+this.TCPClientSocket00.errorcode);
        };

        this.Button06_00_00_onclick = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.errormsg  : "+this.TCPClientSocket00.errormsg);
        };

        this.Button06_00_00_00_onclick = function(obj,e)
        {

        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.Button00.addEventHandler("onclick",this.Button00_onclick,this);
            this.Button01.addEventHandler("onclick",this.Button01_onclick,this);
            this.Button03.addEventHandler("onclick",this.Button03_onclick,this);
            this.Button02.addEventHandler("onclick",this.Button02_onclick,this);
            this.Button04.addEventHandler("onclick",this.Button04_onclick,this);
            this.Button05.addEventHandler("onclick",this.Button05_onclick,this);
            this.Button06.addEventHandler("onclick",this.Button06_onclick,this);
            this.Button06_00.addEventHandler("onclick",this.Button06_00_onclick,this);
            this.Button06_00_00.addEventHandler("onclick",this.Button06_00_00_onclick,this);
            this.Button06_00_00_00.addEventHandler("onclick",this.Button06_00_00_00_onclick,this);
            this.TCPClientSocket00.addEventHandler("onerror",this.TCPClientSocket00_onerror,this);
            this.TCPClientSocket00.addEventHandler("onsuccess",this.TCPClientSocket00_onsuccess,this);
            this.TCPClientSocket00.addEventHandler("ondataarrived",this.TCPClientSocket00_ondataarrived,this);
        };
        this.loadIncludeScript("TCPClientSocket_TestCase1.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
