(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_Work");
            this.set_titletext("Form_Work");
            if (Form == this.constructor)
            {
                this._setFormPosition(1280,720);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("Dataset00", this);
            obj._setContents("");
            this.addChild(obj.name, obj);


            obj = new Dataset("Dataset01", this);
            obj._setContents("");
            this.addChild(obj.name, obj);


            obj = new Dataset("Dataset02", this);
            obj._setContents("<ColumnInfo><Column id=\"Column0\" type=\"STRING\" size=\"256\"/><Column id=\"Column1\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);


            obj = new TCPClientSocket("TCPClientSocket00", this);
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new Button("Button00","7","185","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_text("open");
            this.addChild(obj.name, obj);

            obj = new Static("Static00","30","80","60","30",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_text("server ip");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit00","86","76","152","38",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_value("172.10.12.45");
            obj.set_text("172.10.12.45");
            this.addChild(obj.name, obj);

            obj = new Static("Static00_00","250","81","60","30",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_text("server port");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit00_00","326","78","74","37",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_value("6000");
            obj.set_text("6000");
            this.addChild(obj.name, obj);

            obj = new Button("Button01","112","185","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_text("close");
            this.addChild(obj.name, obj);

            obj = new Button("Button03","340","470","189","60",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_text("textarea clear");
            this.addChild(obj.name, obj);

            obj = new Button("Button02","216","185","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_text("write");
            this.addChild(obj.name, obj);

            obj = new Static("Static00_01_00_00","360","130","59","30",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_text("strCharSet");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_strCharSet","433","127","107","37",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_value("utf-8");
            obj.set_text("utf-8");
            this.addChild(obj.name, obj);

            obj = new Static("Static01","10","132","50","27",null,null,null,null,null,null,this);
            obj.set_taborder("10");
            obj.set_text("write");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_strData","57","127","293","37",null,null,null,null,null,null,this);
            obj.set_taborder("11");
            obj.set_value("abcde");
            obj.set_text("abcde");
            this.addChild(obj.name, obj);

            obj = new Static("Static01_00","34","8","313","53",null,null,null,null,null,null,this);
            obj.set_taborder("12");
            obj.set_text("4. write Method 테스트 ");
            this.addChild(obj.name, obj);

            obj = new Grid("Grid00","567","39","679","681",null,null,null,null,null,null,this);
            obj.set_taborder("13");
            obj.set_binddataset("Dataset02");
            obj.set_autofittype("col");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"34\"/><Column size=\"598\"/></Columns><Rows><Row size=\"24\" band=\"head\"/><Row size=\"50\"/></Rows><Band id=\"head\"><Cell text=\"NO\"/><Cell col=\"1\" text=\"Column1\"/></Band><Band id=\"body\"><Cell text=\"bind:Column0\"/><Cell col=\"1\" text=\"bind:Column1\" displaytype=\"text\" edittype=\"text\" textAlign=\"left\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);
            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","Desktop_screen",1280,720,this,function(p){});
            this.addLayout(obj.name, obj);
            
            // BindItem Information

            
            // TriggerItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("TCPClientSocket_TestCase4.xfdl", function() {

        this.Button00_onclick = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.open start");
        	let userSocket = this.TCPClientSocket00.open(this.Edit00.value, this.Edit00_00.value);
        	uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	let rnt =" this.TCPClientSocket00.open return value="+userSocket;
        	this.Dataset02.setColumn(uRow,1,rnt);
        };

        this.TCPClientSocket00_onerror = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	let uReturn = " e.eventid :"+e.eventid + ", e.statuscode : "+e.statuscode+", e.errormsg : "+e.errormsg;
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,uReturn);

        };

        this.TCPClientSocket00_onsuccess = function(obj,e)
        {

        	let uRow = this.Dataset02.addRow();
        	let uReturn = " e.eventid :"+e.eventid + ", e.reason : "+e.reason+", e.reasonmsg : "+e.reasonmsg+", e.bytessent : "+e.bytessent+", e.bytesremain : "+e.bytesremain;
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,uReturn);
        };
        this.nSize_bytesread=0;
        this.TCPClientSocket00_ondataarrived = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	let uReturn =" e.eventid :"+e.eventid + ", e.bytesread : "+e.bytesread;
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,uReturn);
        	this.nSize_bytesread = e.bytesread;
        };



        this.Button01_onclick = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.close start");
        	let userSocket = this.TCPClientSocket00.close();
        	uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	let rnt =" this.TCPClientSocket00.close return value="+userSocket;
        	this.Dataset02.setColumn(uRow,1,rnt);
        };

        this.Button03_onclick = function(obj,e)
        {
        	this.Dataset02.clearData();

        };

        this.Button02_onclick = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.write start");
        	let bSucc = this.TCPClientSocket00.write(this.edt_strData.value,this.edt_strCharSet.value);
        	trace("Wrie 성공 여부 = [ "+bSucc + " ] ");
        	uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,"bSucc : "+bSucc);
        	uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.write end");
        };

        this.Button04_onclick = function(obj,e)
        {
        	this.TCPClientSocket00.write("GET /transkey.js HTTP/1.1\r\nHost: 172.10.12.45:9090\r\n\r\n");
        };

        this.Button05_onclick = function(obj,e)
        {
        	let arrRecvData = this.TCPClientSocket00.read(this.nSize_bytesread,100,"utf-8");
        	trace(arrRecvData);
        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.Button00.addEventHandler("onclick",this.Button00_onclick,this);
            this.Button01.addEventHandler("onclick",this.Button01_onclick,this);
            this.Button03.addEventHandler("onclick",this.Button03_onclick,this);
            this.Button02.addEventHandler("onclick",this.Button02_onclick,this);
            this.TCPClientSocket00.addEventHandler("onerror",this.TCPClientSocket00_onerror,this);
            this.TCPClientSocket00.addEventHandler("onsuccess",this.TCPClientSocket00_onsuccess,this);
            this.TCPClientSocket00.addEventHandler("ondataarrived",this.TCPClientSocket00_ondataarrived,this);
        };
        this.loadIncludeScript("TCPClientSocket_TestCase4.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
