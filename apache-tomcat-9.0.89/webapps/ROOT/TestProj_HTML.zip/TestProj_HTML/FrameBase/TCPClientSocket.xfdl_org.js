(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("TCPClientSocket");
            this.set_titletext("New Form");
            if (Form == this.constructor)
            {
                this._setFormPosition(1280,720);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new TCPClientSocket("TCPClientSocket00", this);
            this.addChild(obj.name, obj);


            obj = new TCPClientSocket("TCPClientSocket01", this);
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new Button("Button00","54","45","116","50",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_text("open");
            this.addChild(obj.name, obj);

            obj = new Button("Button01","180","45","116","50",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_text("close");
            this.addChild(obj.name, obj);

            obj = new Button("Button02","54","110","116","50",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_text("TEST");
            this.addChild(obj.name, obj);

            obj = new TextArea("TextArea00","54","176","426","214",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            this.addChild(obj.name, obj);

            obj = new Button("Button00_00","564.00","45","116","50",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_text("open");
            this.addChild(obj.name, obj);

            obj = new Button("Button01_00","694.00","45","116","50",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_text("close");
            this.addChild(obj.name, obj);

            obj = new TextArea("TextArea01","566","117","282","96",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_value("GET /~red/qrcode/qrcode.js HTTP/1.1\nHost: localhost:8080\n\n");
            this.addChild(obj.name, obj);

            obj = new Button("Button03","872.00","120","116","50",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_text("write");
            this.addChild(obj.name, obj);

            obj = new TextArea("TextArea02","566","224","283","176",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            this.addChild(obj.name, obj);

            obj = new Button("Button04","872.00","230","116","50",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_text("read");
            this.addChild(obj.name, obj);

            obj = new Button("Button05","872.00","290","116","50",null,null,null,null,null,null,this);
            obj.set_taborder("10");
            obj.set_text("readLine");
            this.addChild(obj.name, obj);
            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","",1280,720,this,function(p){});
            this.addLayout(obj.name, obj);
            
            // BindItem Information

            
            // TriggerItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("TCPClientSocket.xfdl", function() {

         /*
          *   TCPClientSocket00 TEST
          *   ======================
          */

        this.TCPClientSocket00_onerror = function(obj,e)
        {
        	trace("this.TCPClientSocket00_onerror: [" + e.statuscode + "] " + e.errormsg);
        };

        this.TCPClientSocket00_onsuccess = function(obj,e)
        {
        	trace("this.TCPClientSocket00_onsuccess: [" + e.reason + "] " + e.reasonmsg + " { sent : " + e.bytessent + ", remain : " + e.bytesremain + "}");
        };

        this.TCPClientSocket00_ondataarrived = function(obj,e)
        {
        	trace("this.TCPClientSocket00_ondataarrived: bytes => " + e.bytesread);
        	if (e.bytesread > 0)
        	{
        		var ret = this.TCPClientSocket00.read(e.bytesread, 30, "utf-8");
        		this.TextArea00.set_value(this.TextArea00.text + ret[1]);
        	}
        };

        this.Button00_onclick = function(obj,e)
        {
        	this.TCPClientSocket00.open("172.10.12.45", 6000);
        };

        this.Button01_onclick = function(obj,e)
        {
        	this.TCPClientSocket00.close();
        };

        this.Button02_onclick = function(obj,e)
        {
        	this.TextArea00.set_value("");
        	this.TCPClientSocket00.write("GET /~red/qrcode/qrcode.js HTTP/1.1\r\nHost: localhost:8080\r\n\r\n");
        };

         /*
          *   TCPClientSocket01 TEST
          *   ======================
          */

        this.__read_size = 0;
        this.TCPClientSocket01_ondataarrived = function(obj,e)
        {
        	trace("this.TCPClientSocket01_ondataarrived: bytes => " + e.bytesread);
        	this.__read_size = e.bytesread;
        };

        this.TCPClientSocket01_onerror = function(obj,e)
        {
        	trace("this.TCPClientSocket01_onerror: [" + e.statuscode + "] " + e.errormsg);
        };

        this.TCPClientSocket01_onsuccess = function(obj,e)
        {
        	trace("this.TCPClientSocket01_onsuccess: [" + e.reason + "] " + e.reasonmsg + " { sent : " + e.bytessent + ", remain : " + e.bytesremain + "}");
        };

        this.Button00_00_onclick = function(obj,e)
        {
        	this.TCPClientSocket01.open("172.10.12.65", 58080);
        };

        this.Button01_00_onclick = function(obj,e)
        {
        	this.TCPClientSocket01.close();
        };

        this.Button03_onclick = function(obj,e)
        {
        	this.TextArea02.set_value("");
        	this.TCPClientSocket01.write(this.TextArea01.value);
        };

        this.Button04_onclick = function(obj,e)
        {
        	var readSize = this.__read_size;
        	if (readSize <= 0)
        		readSize = 1024;

        	var ret = this.TCPClientSocket01.read(readSize, 30, "utf-8");
        	if (ret[0])
        	{
        		var str = ret[1];
        		var text = this.TextArea02.value;
        		if (!text)
        			text = str;
        		else
        			text += str;
        		this.TextArea02.set_value(text);

        		// trace("TCPClientSocket00<readLine>: str => " + str);
        	}
        };

        this.Button05_onclick = function(obj,e)
        {
        	var readSize = this.__read_size;
        	if (readSize <= 0)
        		readSize = 1024;

        	var ret = this.TCPClientSocket01.readLine(readSize);
        	if (ret[0])
        	{
        	    var str = ret[1];
        		var text = this.TextArea02.value;
        		if (!text)
        			text = str;
        		else
        			text += str;
        		this.TextArea02.set_value(text);

        		trace("TCPClientSocket00<readLine>: str => " + str);
        	}
        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.Button00.addEventHandler("onclick",this.Button00_onclick,this);
            this.Button01.addEventHandler("onclick",this.Button01_onclick,this);
            this.Button02.addEventHandler("onclick",this.Button02_onclick,this);
            this.Button00_00.addEventHandler("onclick",this.Button00_00_onclick,this);
            this.Button01_00.addEventHandler("onclick",this.Button01_00_onclick,this);
            this.Button03.addEventHandler("onclick",this.Button03_onclick,this);
            this.Button04.addEventHandler("onclick",this.Button04_onclick,this);
            this.Button05.addEventHandler("onclick",this.Button05_onclick,this);
            this.TCPClientSocket00.addEventHandler("onerror",this.TCPClientSocket00_onerror,this);
            this.TCPClientSocket00.addEventHandler("onsuccess",this.TCPClientSocket00_onsuccess,this);
            this.TCPClientSocket00.addEventHandler("ondataarrived",this.TCPClientSocket00_ondataarrived,this);
            this.TCPClientSocket01.addEventHandler("ondataarrived",this.TCPClientSocket01_ondataarrived,this);
            this.TCPClientSocket01.addEventHandler("onerror",this.TCPClientSocket01_onerror,this);
            this.TCPClientSocket01.addEventHandler("onsuccess",this.TCPClientSocket01_onsuccess,this);
        };
        this.loadIncludeScript("TCPClientSocket.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
