(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_Work");
            this.set_titletext("Form_Work");
            if (Form == this.constructor)
            {
                this._setFormPosition(1280,720);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("Dataset00", this);
            obj._setContents("");
            this.addChild(obj.name, obj);


            obj = new Dataset("Dataset01", this);
            obj._setContents("");
            this.addChild(obj.name, obj);


            obj = new Dataset("Dataset02", this);
            obj._setContents("<ColumnInfo><Column id=\"Column0\" type=\"STRING\" size=\"256\"/><Column id=\"Column1\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new Button("Button00","125","140","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_text("open");
            this.addChild(obj.name, obj);

            obj = new Static("Static00","30","80","60","30",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_text("server ip");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit00","86","76","152","38",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_value("172.10.12.45");
            obj.set_text("172.10.12.45");
            this.addChild(obj.name, obj);

            obj = new Static("Static00_00","250","81","60","30",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_text("server port");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit00_00","326","78","74","37",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_value("6000");
            obj.set_text("6000");
            this.addChild(obj.name, obj);

            obj = new Button("Button01","230","140","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_text("close");
            this.addChild(obj.name, obj);

            obj = new Button("Button03","340","470","189","60",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_text("textarea clear");
            this.addChild(obj.name, obj);

            obj = new Button("Button04","20","140","100","50",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_text("동적생성");
            this.addChild(obj.name, obj);

            obj = new Static("Static01_00","34","8","313","53",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_text("6. TCPClientSocket 동적생성 테스트 ");
            this.addChild(obj.name, obj);

            obj = new Grid("Grid00","567","39","679","484",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_binddataset("Dataset02");
            obj.set_autofittype("col");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"34\"/><Column size=\"598\"/></Columns><Rows><Row size=\"24\" band=\"head\"/><Row size=\"50\"/></Rows><Band id=\"head\"><Cell text=\"NO\"/><Cell col=\"1\" text=\"Column1\"/></Band><Band id=\"body\"><Cell text=\"bind:Column0\"/><Cell col=\"1\" text=\"bind:Column1\" displaytype=\"text\" edittype=\"text\" textAlign=\"left\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);
            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","Desktop_screen",1280,720,this,function(p){});
            this.addLayout(obj.name, obj);
            
            // BindItem Information

            
            // TriggerItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("TCPClientSocket_TestCase6.xfdl", function() {
        this.uTCP=null;
        this.Button04_onclick = function(obj,e)
        {
        	if(this.uTCP == null || this.uTCP == undefined || this.uTCP == "undefined" || this.uTCP == "unll" || this.uTCP == NULL || this.uTCP == UNDEFINED)
        	{
        		this.uTCP = new nexacro.TCPClientSocket();
        		let uRow = this.Dataset02.addRow();
        		this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        		this.Dataset02.setColumn(uRow,1," this.uTCP 생성여부 " +this.uTCP);
        		let nIndex = this.uTCP.addEventHandler( "onsuccess", this.TCPClientSocket00_onsuccess, this);
        		uRow = this.Dataset02.addRow();
        		this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        		this.Dataset02.setColumn(uRow,1," this.uTCP  onsuccess addEventHandler 성공여부 " +nIndex);
        		nIndex = this.uTCP.addEventHandler( "onerror", this.TCPClientSocket00_onerror, this);
        		uRow = this.Dataset02.addRow();
        		this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        		this.Dataset02.setColumn(uRow,1," this.uTCP  onerror addEventHandler 성공여부 " +nIndex);
        		nIndex = this.uTCP.addEventHandler( "ondataarrived", this.TCPClientSocket00_ondataarrived, this);
        		uRow = this.Dataset02.addRow();
        		this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        		this.Dataset02.setColumn(uRow,1," this.uTCP  ondataarrived addEventHandler 성공여부 " +nIndex);

        	}

        };

        this.Button00_onclick = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.uTCP.open start");
        	let userSocket = this.uTCP.open(this.Edit00.value, this.Edit00_00.value);
        	uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	let rnt =" this.uTCP.open return value="+userSocket;
        	this.Dataset02.setColumn(uRow,1,rnt);

        };



        this.Button01_onclick = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.uTCP.close start");
        	let userSocket = this.uTCP.close();
        	uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	let rnt =" this.uTCP.close return value="+userSocket;
        	this.Dataset02.setColumn(uRow,1,rnt);
        };
        this.TCPClientSocket00_onerror = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	let uReturn = " e.eventid :"+e.eventid + ", e.statuscode : "+e.statuscode+", e.errormsg : "+e.errormsg;
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,uReturn);

        };

        this.TCPClientSocket00_onsuccess = function(obj,e)
        {

        	let uRow = this.Dataset02.addRow();
        	let uReturn = " e.eventid :"+e.eventid + ", e.reason : "+e.reason+", e.reasonmsg : "+e.reasonmsg+", e.bytessent : "+e.bytessent+", e.bytesremain : "+e.bytesremain;
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,uReturn);
        };

        this.TCPClientSocket00_ondataarrived = function(obj,e)
        {
        	let uRow = this.Dataset02.addRow();
        	let uReturn =" e.eventid :"+e.eventid + ", e.bytesread : "+e.bytesread;
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,uReturn);
        	this.edt_nSize.value = e.bytesread;
        };
        this.Button03_onclick = function(obj,e)
        {
        	this.Dataset02.clearData();

        };
        /*
        this.Button02_onclick = function(obj:nexacro.Button,e:nexacro.ClickEventInfo)
        {
        	let uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.write start");
        	let bSucc = this.TCPClientSocket00.readLine(10);
        	uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,"bSucc[0]"+bSucc[0]);
        		uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,"bSucc[1]"+bSucc[1]);
        	uRow = this.Dataset02.addRow();
        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1,"bSucc : "+bSucc);

        	this.Dataset02.setColumn(uRow,0,this.Dataset02.getRowCount());
        	this.Dataset02.setColumn(uRow,1," this.TCPClientSocket00.write end");
        };



        */
        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.Button00.addEventHandler("onclick",this.Button00_onclick,this);
            this.Button01.addEventHandler("onclick",this.Button01_onclick,this);
            this.Button03.addEventHandler("onclick",this.Button03_onclick,this);
            this.Button04.addEventHandler("onclick",this.Button04_onclick,this);
        };
        this.loadIncludeScript("TCPClientSocket_TestCase6.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
